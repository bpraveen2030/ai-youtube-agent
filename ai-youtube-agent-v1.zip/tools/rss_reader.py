from agents.news_scout import scout_news

if __name__ == "__main__":
    for story in scout_news():
        print(story)
